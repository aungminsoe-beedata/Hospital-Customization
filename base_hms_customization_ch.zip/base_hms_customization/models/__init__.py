# -*- coding: utf-8 -*-

from . import models
from . import medical_investigation
from . import investigation_info
from . import operation_note
from . import medical_patient_inherit

from . import patient_rooms
from . import medical_inpatient_registeration_inherit
from . import product_category
from . import medical_physicians
from . import sale_order_line_inherit

from . import account_move_line_view
from . import referral_payment

from . import pos_session
from . import pos_order
