# -*- coding: utf-8 -*-

from . import models
from . import patient_form_view
from . import inpatient_form_view
from . import res_pa
