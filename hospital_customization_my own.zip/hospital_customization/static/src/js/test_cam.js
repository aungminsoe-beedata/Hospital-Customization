/** @odoo-module **/
import { patch } from "@web/core/utils/patch";
import { ImageField } from "@web/views/fields/image/image_field";

const composerPatch = {
    async onClickCamera(ev) { 
        console.log('Webcam button clicked', ev);
    
        // Request camera access from the user
        try {
            // Get available video input devices
            const devices = await navigator.mediaDevices.enumerateDevices();
            const videoDevices = devices.filter(device => device.kind === 'videoinput');

            if (videoDevices.length === 0) {
                alert("No video devices found.");
                return;
            }

            // Create a wrapper div for the video and buttons
            const wrapper = document.createElement('div');
            wrapper.style.position = 'fixed';
            wrapper.style.top = '10px';
            wrapper.style.right = '10px';
            wrapper.style.width = '500px';
            wrapper.style.height = '500px';
            wrapper.style.border = '1px solid #ccc';
            wrapper.style.borderRadius = '5px';
            wrapper.style.overflow = 'hidden';
            wrapper.style.backgroundColor = '#fff';
            wrapper.style.zIndex = '1000'; // Ensure it's on top

            // Create the select dropdown for video devices
            const deviceSelect = document.createElement('select');
            videoDevices.forEach(device => {
                const option = document.createElement('option');
                option.value = device.deviceId;
                console.log(device.label, 'device name');
                option.textContent = device.label || `Camera ${device.deviceId}`;
                deviceSelect.appendChild(option);
            });

            // Create the video element
            const videoElement = document.createElement('video');
            videoElement.style.width = '100%';
            videoElement.style.height = '100%';

            // Create a label for device type
            const deviceLabel = document.createElement('p');
            deviceLabel.textContent = "Select a camera device:";
            deviceLabel.style.fontWeight = 'bold';
            deviceLabel.style.margin = '10px'; // Add some margin for styling

            // Create the close button
            const closeButton = document.createElement('button');
            closeButton.innerHTML = '✖'; // Cross icon
            closeButton.style.position = 'absolute';
            closeButton.style.top = '0';
            closeButton.style.right = '0';
            closeButton.style.backgroundColor = 'red';
            closeButton.style.color = 'white';
            closeButton.style.border = 'none';
            closeButton.style.width = '20px';
            closeButton.style.height = '20px';
            closeButton.style.cursor = 'pointer';
            closeButton.style.fontSize = '12px';

            // Stop the camera and remove the wrapper when close button is clicked
            closeButton.onclick = function () {
                stream.getTracks().forEach(track => track.stop()); // Stop the camera
                wrapper.remove(); // Remove the video and button from DOM
            };

            // Create the Capture button
            const captureButton = document.createElement('button');
            captureButton.innerHTML = 'Capture';
            captureButton.style.position = 'absolute';
            captureButton.style.bottom = '10px';
            captureButton.style.left = '10px';
            captureButton.style.backgroundColor = '#4CAF50'; // Green background
            captureButton.style.color = 'white';
            captureButton.style.border = 'none';
            captureButton.style.padding = '10px 15px';
            captureButton.style.cursor = 'pointer';
            captureButton.style.borderRadius = '5px';

            // Append the label, select, video, and close button to the wrapper
            wrapper.appendChild(deviceLabel); // Append device type label
            wrapper.appendChild(deviceSelect);
            wrapper.appendChild(videoElement);
            wrapper.appendChild(closeButton);
            wrapper.appendChild(captureButton);

            // Function to start the video stream from the selected device
            async function startVideo(deviceId) {
                // Stop any existing stream
                if (stream) {
                    stream.getTracks().forEach(track => track.stop());
                }
                // Request camera access from the selected device
                stream = await navigator.mediaDevices.getUserMedia({
                    video: { deviceId: { exact: deviceId } }
                });
                videoElement.srcObject = stream;
                videoElement.play();
            }

            // Start video stream with the first device initially
            let stream = await navigator.mediaDevices.getUserMedia({ video: { deviceId: { exact: videoDevices[0].deviceId } } });
            videoElement.srcObject = stream;
            videoElement.play();

            // Listen for changes on the select dropdown to switch cameras
            deviceSelect.addEventListener('change', (event) => {
                const selectedDeviceId = event.target.value;
                startVideo(selectedDeviceId);
            });

            // Functionality for Capture button
            captureButton.onclick = () => {
                // Create a canvas to capture the frame
                const canvas = document.createElement('canvas');
                canvas.width = 500; // Set the width of the canvas
                canvas.height = 500; // Set the height of the canvas
                const ctx = canvas.getContext('2d');
                ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
                
                // Convert the canvas to a data URL (base64)
                const dataURL = canvas.toDataURL('image/png');
                console.log('Captured image data:', dataURL);

                // Create an image element to display the captured image temporarily
                const tempImage = document.createElement('img');
                tempImage.src = dataURL;
                tempImage.style.position = 'fixed';
                tempImage.style.top = '10px'; // Adjust as needed
                tempImage.style.left = '10px'; // Positioning on the left
                tempImage.style.width = '200px'; // Set the width as needed
                tempImage.style.height = 'auto'; // Maintain aspect ratio
                tempImage.style.border = '2px solid #4CAF50'; // Optional styling
                tempImage.style.borderRadius = '5px'; // Optional styling

                // Append the captured image to the body
                document.body.appendChild(tempImage);

                // Create the Save button
                const saveButton = document.createElement('button');
                saveButton.innerHTML = 'Save';
                saveButton.style.position = 'absolute';
                saveButton.style.bottom = '10px';
                saveButton.style.right = '10px';
                saveButton.style.backgroundColor = '#2196F3'; // Blue background
                saveButton.style.color = 'white';
                saveButton.style.border = 'none';
                saveButton.style.padding = '10px 15px';
                saveButton.style.cursor = 'pointer';
                saveButton.style.borderRadius = '5px';

                // Create the Cancel button
                const cancelButton = document.createElement('button');
                cancelButton.innerHTML = 'Cancel';
                cancelButton.style.position = 'absolute';
                cancelButton.style.bottom = '10px';
                cancelButton.style.right = '120px'; // Positioning next to Save button
                cancelButton.style.backgroundColor = '#f44336'; // Red background
                cancelButton.style.color = 'white';
                cancelButton.style.border = 'none';
                cancelButton.style.padding = '10px 15px';
                cancelButton.style.cursor = 'pointer';
                cancelButton.style.borderRadius = '5px';

                // Append the Save and Cancel buttons to the wrapper
                wrapper.appendChild(saveButton);
                wrapper.appendChild(cancelButton);

                // Functionality for Save button
                saveButton.onclick = async () => {
                    console.log('Save button clicked - implement save functionality with image data:', dataURL);
                    // Implement saving functionality here
                };

                // Functionality for Cancel button
                cancelButton.onclick = () => {
                    // Hide the temporary image
                    tempImage.remove();
                    // Just remove the Save and Cancel buttons
                    saveButton.remove();
                    cancelButton.remove();
                };
            };

            // Append the wrapper to the document body
            document.body.appendChild(wrapper);
            
        } catch (err) {
            console.error("Error accessing webcam: ", err);
            alert(`Failed to access the webcam: ${err.message}`);
        }
    }
}

patch(ImageField.prototype, composerPatch);
