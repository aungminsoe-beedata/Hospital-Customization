# -*- coding: utf-8 -*-
{
    'name': "Hospital Customization Odoo 17",

    'summary': "Short (1 phrase/line) summary of the module's purpose",

    'description': """
Long description of module's purpose
    """,

    'author': "BEE Data",
    'website': "https://www.yourcompany.com",
    'category': 'Uncategorized',
    'version': '0.1',
    'depends': ['base','base_hospital_management','sale'],
    'data': [
        # 'security/ir.model.access.csv',
        'security/security.xml',
        'views/menuitems.xml',
        'views/inpatient_view.xml',
        'views/inpatient_tree_view.xml',
        
        'views/patient_tree_view.xml',
        'views/doctor_allocation_view.xml',
    ],
    'demo': [
        'demo/demo.xml',
    ],
}

